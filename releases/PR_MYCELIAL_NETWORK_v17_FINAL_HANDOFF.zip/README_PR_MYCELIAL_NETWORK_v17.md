# PR_MYCELIAL_NETWORK_v17 — Final Project Handoff

## Status

This is the final handoff package for the Puerto Rico mycelial habitat/connectivity research workflow.

## Included

- FINAL_PROJECT_HANDOFF_v17.csv
- OPEN_ISSUES_REGISTER_v17.csv
- REPRODUCIBILITY_TASK_QUEUE_v17.csv
- FINAL_VERSIONED_ARCHIVE_INDEX_v17.csv
- FINAL_RELEASE_DECISION_v17.csv
- PACKAGE_METADATA_v17.json

## Release posture

Research-only. Habitat-scale. Non-deployment-cleared.

This package is not:
- a field access authorization
- a route clearance product
- a permit
- a collection guide
- a precise active/regulated taxon location product

## Required next work

Before any field deployment:
1. Join official parcel/ownership data.
2. Join protected-area and managing-agency rules.
3. Join trail/road access and closure data.
4. Run legal/access clearance QA.
5. Use non-invasive survey protocols only.
